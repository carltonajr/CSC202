// ***Week 1 Assignment Updates:
// Initial project creation and GUI build.
// ***Week 2 Assignment Updates:
// Added and implemented "loginattempts", "currentUser" and "isLoggedIn".
// ***Week 3 Assignment Updates:
// Added and implemented "ResetLoginAttempts" and "LoginFormLoad" to the login process.
// Added "WelcomeLabel" to the form when loaded.
// Added "AddFoodToTracker" for creating inventory to create meal plan from.
// ***Week 4
// Moved "AddFoodToTracker" to meal_plan.cs file along with 2 buttons and listview.
// Updated maneuvering between both forms.
// Removed temporary message for updating inventory process.

//* Continue work on LoginFormLoad as the logic allows incorrect username/password to pass as long as text lengths are correct

using System.Diagnostics.Eventing.Reader;

namespace growth_c_sharp
{
    // Main form class for the Growth application
    public partial class Growth : Form
    {
        // assigns priority to the open create tab when opened.
        public bool Priority(bool process)
        {
            while (true)
            {
                Home_label.Enabled = false;
                Create_label.Visible = false;
                Connect_label.Enabled = false;
                Updates_label.Enabled = false;
            }
        }
        // Initialize the Growth Form
        public Growth()
        {
            InitializeComponent();
        }
        // On loading of the Growth form, produce the welcome label and disable log out button.
        public void Growth_Form1_Load(object sender, EventArgs e)
        {
            WelcomeLabel("growth.");
            log_out.Enabled = false;
        }
        // Tracks how many failed login attempts the user has made
        int loginattempts = 0;

        // Stores the current username after login
        string activeUser = "admin";
        string activePassword = "password";
        // Tracks whether the user is logged in or not
        bool isLoggedIn = false;

        // Displays the word logo of the company. Placed in the form loading action.
        internal void WelcomeLabel(string message)
        {
            // Display app name on startup
            welcome_message.Text = message;
        }

        // Function that validates whether the user's login credentials are correct
        // Returns a boolean value indicating if the user is logged in or not
        internal bool ValidLogin(bool isLoggedIn)
        {
            // Updates the UI based on the current login state
            LoginFormLoad(isLoggedIn);

            // Checks if the entered username and password match the stored credentials
            if (activeUser == user_textbox.Text && activePassword == password_textbox.Text)
            {
                // If both match, set login status to true
                isLoggedIn = true;
            }
            else
            {
                // If either does not match, set login status to false
                isLoggedIn = false;
            }

            // Return the final login status
            return isLoggedIn;
        }

        // Essentinally adds and removes login form from page
        internal bool LoginFormLoad(bool isLoggedIn)
        {
            // If login was successful
            if (isLoggedIn == true)
            {
                MessageBox.Show("Login Success, loading...", "Login Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Ensure loginattempts is reset for when user logs out
                loginattempts = 0;

                // Enable Log Out Button
                log_out.Visible = true;
                log_out.Enabled = true;

                // Clear attempt text
                login_attempt_count.Text = "";

                // Display welcome message
                welcome_user.Text = "welcome, " + activeUser;
                // Clear error message
                error_label.Text = "";

                // Hide and disable login-related UI elements
                LoginButton.Enabled = false;
                Reset_button.Enabled = false;
                Login.Text = "";
                LoginButton.Visible = false;
                Reset_button.Visible = false;
                user_textbox.Visible = false;
                password_textbox.Visible = false;
                Username.Visible = false;
                Password.Visible = false;
            }
            else
            {
                isLoggedIn = false;
                // clear out both user entry text boxes
                user_textbox.Text = "";
                password_textbox.Text = "";

                // show and enable login-related UI elements
                LoginButton.Enabled = true;
                Reset_button.Enabled = true;
                Login.Text = "Login";
                LoginButton.Visible = true;
                Reset_button.Visible = true;
                user_textbox.Visible = true;
                password_textbox.Visible = true;
                Username.Visible = true;
                Password.Visible = true;
                welcome_user.Text = "";

                // Disable Log Out Button
                log_out.Visible = false;
                log_out.Enabled = false;
            }
            return isLoggedIn;
        }

        // Resets the login attempt counter and requests user to reset password when attempts run out
        internal int ResetLoginAttempts(int loginattempts)
        {
            if (loginattempts > 4)
            {
                LoginButton.Enabled = false;
                login_attempt_count.Text = "No attempts remaining. Please reset password.";
                error_label.Text = "";
            }
            return 0;
        }
        // Home link clicked
        private void Home_label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Returns to Home Page"); // Temporary feedback
        }

        // Create link clicked runs "build_meal_plan" and "Priority"
        public void Create_label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (isLoggedIn == true)
            {
                meal_plan build_meal_plan = new meal_plan();
                build_meal_plan.Show();
              //Priority(true);
            }
            else
            {
                MessageBox.Show("Please login before accessing.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Updates link clicked
        private void Updates_label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Link to the company updates and information page.");
        }

        // Connect link clicked
        private void Connect_label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Link to the connection pages such as the company website and social media pages.");
        }

        // Login button click event
        private void LoginButton_Click(object sender, EventArgs e)
        {
            loginattempts += 1; // Increase attempt counter

            // Check if username or password is too short
            if (user_textbox.TextLength < 5 || password_textbox.TextLength < 8)
            {
                // Only allow up to 5 failed attempts
                if (loginattempts <= 5)
                {
                    // Show remaining attempts
                    login_attempt_count.Text = "Login attempts remaining: " + (5 - loginattempts);

                    // Display error message
                    error_label.Text = "Please check username or password.";
                }
                // Runs ResetLoginAttempts when the attempts reaches 5.
                if (loginattempts == 5)
                { ResetLoginAttempts(loginattempts); }
            }
            else
            {
                if (ValidLogin(isLoggedIn = true))
                {
                    // Mark user as logged in if inputs are valid
                    LoginFormLoad(isLoggedIn);

                }
            }
        }

        // Reset button click event
        private void Reset_button_Click(object sender, EventArgs e)
        {
            // Clear welcome message
            welcome_message.Text = activeUser;

            // Disable buttons and links
            LoginButton.Enabled = false;
            Create_label.Enabled = false;
            Updates_label.Enabled = false;
            Connect_label.Enabled = false;

            // Hide buttons and links
            LoginButton.Visible = false;
            Create_label.Visible = false;
            Updates_label.Visible = false;
            Connect_label.Visible = false;
        }
        // Confirms when log out button is clicked, the user is logged out.
        private void Log_out_Click(object sender, EventArgs e)
        {
            LoginFormLoad(isLoggedIn = false);
        }
    }
}