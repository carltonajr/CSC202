﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Text;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace growth_c_sharp
{
    // Meal plan form class that manages food tracking functionality
    public partial class meal_plan : Form
    {

        // Constructor that runs when the meal plan form is created
        // Initializes all UI components on the form
        public meal_plan()
        {
            InitializeComponent();
        }

        // Function that adds a food item to the ListView tracker
        // Returns true if the item is added successfully, otherwise false
        public bool AddFoodToTracker(string foodName, string food_type, double est_calories, double est_sugar)
        {
            try
            {
                // Creates a new ListViewItem using the food name
                ListViewItem newfood = new ListViewItem(foodName);

                // Adds the new food item to the ListView control
                foodList.Items.Add(newfood);

                // Returns true to indicate the food was added successfully
                return true;
            }
            catch
            {
                // Returns false if an error occurs while adding the item
                return false;
            }
        }
        //Converts the input text to the needed data type
        public double Data_Type_Convert(string value)
        {
            // try parsing the value and converting to double
            try
            {
                double ready_to_store = double.Parse(value);
                return ready_to_store;
            }
            // loads a message box when the value is unable to be changed to a double data type.
            catch
            {
                MessageBox.Show(
                    "Error Stop 1", "Data Entry Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error
                );
                // sets the return value of 0
                return 0.0;
            }
        }

        // Event handler for when the "Add Foods" button is clicked
        // Enabling, disabling and making element visible.
        private void add_foods_Click(object sender, EventArgs e)
        {
            foodname.Visible = true;
            foodname_label.Visible = true;
            foodtype.Visible = true;
            foodtype_label.Visible = true;
            calories_est_textbox.Visible = true;
            calories_label.Visible = true;
            sugar_est_textbox.Visible = true;
            sugar_label.Visible = true;
            submit_entry_button.Visible = true;
            submit_entry_button.Enabled = true;
            
        }
        // When clicking the submit entry button perform these checks
        // if they pass all conditions, add the entries to the listview
        // and 'reset' the form
        private void submit_entry_button_Click(object sender, EventArgs e)
        {
            edit_inventory.Enabled = false;
            if (foodname.TextLength < 3)
            {
                MessageBox.Show("Please review the name of the food given.", "Missing/ Incomplete Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (foodtype.SelectedIndex <= 0)
            {
                MessageBox.Show("Please select a food type.", "Missing/ Incomplete Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (Data_Type_Convert(calories_est_textbox.Text) == 0.0 || Data_Type_Convert(sugar_est_textbox.Text) == 0.0)
            {
                MessageBox.Show("Error Stop 2", "Data Entry Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            // string foodName, string food_type, double est_calories, double est_sugar
            {
                AddFoodToTracker(foodname.Text, foodtype.SelectedText, Data_Type_Convert(calories_est_textbox.Text), Data_Type_Convert(sugar_est_textbox.Text));
                foodname.Text = "";
                foodtype.SelectedIndex = 0;
                calories_est_textbox.Text = "";
                sugar_est_textbox.Text = "";
                edit_inventory.Enabled = true;
                add_foods.Enabled = true;
            }
        }
    }
}
