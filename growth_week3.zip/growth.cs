// ***Week 1 Assignment Updates:
// Initial project creation and GUI build.
// ***Week 2 Assignment Updates:
// Added and implemented "loginattempts", "currentUser" and "isLoggedIn".
// ***Week 3 Assignment Updates:
// Added and implemented "ResetLoginAttempts" and "LoginFormLoad" to the login process.
// Added "WelcomeLabel" to the form when loaded.
// Added "AddFoodToTracker" for creating inventory to create meal plan from.

//* Continue work on LoginFormLoad as the logic allows incorrect username/password to pass as long as text lengths are correct

namespace growth_c_sharp
{
    // Main form class for the Growth application
    public partial class Growth : Form
    {
        //Function that adds foods to the inventory
        internal bool AddFoodToTracker(string foodName, int est_calories, int est_sugar)
        {
            try
            {
                // Creates new item in the listview
                ListViewItem newfood = new ListViewItem(foodName);

                //Add new item to the listview
                foodList.Items.Add(newfood);
                return true; // returns true if added successfully
            }
            catch
            {
                return false; // something went wrong
            }
        }

        // Tracks how many failed login attempts the user has made
        int loginattempts = 0;

        // Stores the current username after login
        readonly string currentUser = "";
        string activeUser = "admin";
        string activePassword = "password";

        // Tracks whether the user is logged in or not
        bool isLoggedIn = false;

        // Displays the word logo of the company. Placed in the form loading action.
        internal void WelcomeLabel(string message)
        {
            // Display app name on startup
            welcome_message.Text = message;
        }

        internal bool ValidLogin(bool isLoggedIn) 
        {
            LoginFormLoad(isLoggedIn);
            if (activeUser == user_textbox.Text && activePassword == password_textbox.Text)
            {
                isLoggedIn = true;
            }
            else
            {
                isLoggedIn = false;
            }
            return isLoggedIn;
        }
        // Essentinally adds and removes login form from page
        internal bool LoginFormLoad(bool isLoggedIn)
        {
            // If login was successful
            if (isLoggedIn == true)
            {
                // Ensure loginattempts is reset for when user logs out
                loginattempts = 0;

                // Enable Log Out Button
                log_out.Visible = true;
                log_out.Enabled = true;

                // Clear attempt text
                login_attempt_count.Text = "";

                // Display welcome message
                welcome_user.Text = "welcome, " + activeUser;
                // Clear error message
                error_label.Text = "";

                // Hide and disable login-related UI elements
                LoginButton.Enabled = false;
                Reset_button.Enabled = false;
                Login.Text = "";
                LoginButton.Visible = false;
                Reset_button.Visible = false;
                user_textbox.Visible = false;
                password_textbox.Visible = false;
                Username.Visible = false;
                Password.Visible = false;
            }
            else 
            {
                isLoggedIn = false;
                // clear out both user entry text boxes
                user_textbox.Text = "";
                password_textbox.Text = "";

                // show and enable login-related UI elements
                LoginButton.Enabled = true;
                Reset_button.Enabled = true;
                Login.Text = "Login";
                LoginButton.Visible = true;
                Reset_button.Visible = true;
                user_textbox.Visible = true;
                password_textbox.Visible = true;
                Username.Visible = true;
                Password.Visible = true;
                welcome_user.Text = "";

                // Disable Log Out Button
                log_out.Visible = false;
                log_out.Enabled = false;
            }
                return isLoggedIn;
        }

        // Resets the login attempt counter and requests user to reset password when attempts run out
        internal int ResetLoginAttempts(int loginattempts)
        {
            if (loginattempts > 4)
            {
                LoginButton.Enabled = false;
                login_attempt_count.Text = "No attempts remaining. Please reset password.";
                error_label.Text = "";
            }
            return 0;
        }
        // Form constructor
        public Growth()
        {
            InitializeComponent(); // Loads all GUI components
        }
        // Home link clicked
        private void Home_label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Returns to Home Page"); // Temporary feedback
        }

        // Create link clicked
        private void Create_label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //MessageBox.Show("Link to the page where you can create and manage meal plans, if logged in. If not logged in, it will bring up the login action.");
            
            //Enable and show the Food List, Function that adds to it.
            AddFoodToTracker("Banana", 105, 15);
            foodList.Enabled = true;
            foodList.Visible = true;
        }

        // Updates link clicked
        private void Updates_label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Link to the company updates and information page.");
        }

        // Connect link clicked
        private void Connect_label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Link to the connection pages such as the company website and social media pages.");
        }

        // Login button click event
        private void LoginButton_Click(object sender, EventArgs e)
        {
            loginattempts += 1; // Increase attempt counter

            // Check if username or password is too short
            if (user_textbox.TextLength < 5 || password_textbox.TextLength < 8)
            {
                // Only allow up to 5 failed attempts
                if (loginattempts <= 5)
                {
                    // Show remaining attempts
                    login_attempt_count.Text = "Login attempts remaining: " + (5 - loginattempts);

                    // Display error message
                    error_label.Text = "Please check username or password.";
                }
                // Runs ResetLoginAttempts when the attempts reaches 5.
                if (loginattempts == 5)
                { ResetLoginAttempts(loginattempts); }
            }
            else
            {
                if (ValidLogin(isLoggedIn = true)) 
                {
                    // Mark user as logged in if inputs are valid
                    LoginFormLoad(isLoggedIn);
                }
            }
        }

        // Reset button click event
        private void Reset_button_Click(object sender, EventArgs e)
        {
            // Clear welcome message
            welcome_message.Text = activeUser;

            // Disable buttons and links
            LoginButton.Enabled = false;
            Create_label.Enabled = false;
            Updates_label.Enabled = false;
            Connect_label.Enabled = false;

            // Hide buttons and links
            LoginButton.Visible = false;
            Create_label.Visible = false;
            Updates_label.Visible = false;
            Connect_label.Visible = false;
        }

        // Runs when the form first loads
        private void Growth_Form1_Load(object sender, EventArgs e)
        {
            WelcomeLabel("growth.");
            // Confirm the logout button is not usable until called upon
            log_out.Visible = false;
            log_out.Enabled = false;
            foodList.Visible = false;
            foodList.Enabled = false;
        }

        private void Log_out_Click(object sender, EventArgs e)
        {
            LoginFormLoad(isLoggedIn = false);
        }
    }
}
