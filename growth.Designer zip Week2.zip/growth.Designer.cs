﻿namespace growth_c_sharp
{
    partial class Growth
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Home_label = new LinkLabel();
            Create_label = new LinkLabel();
            Updates_label = new LinkLabel();
            Connect_label = new LinkLabel();
            user_textbox = new TextBox();
            password_textbox = new TextBox();
            Login = new Label();
            Username = new Label();
            Password = new Label();
            LoginButton = new Button();
            Reset_button = new Button();
            welcome_message = new Label();
            error_label = new Label();
            login_attempt_count = new Label();
            welcome_user = new Label();
            SuspendLayout();
            // 
            // Home_label
            // 
            Home_label.AutoSize = true;
            Home_label.Font = new Font("Georgia", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
            Home_label.ForeColor = Color.FromArgb(30, 30, 30);
            Home_label.LinkBehavior = LinkBehavior.NeverUnderline;
            Home_label.LinkColor = Color.FromArgb(30, 30, 30);
            Home_label.Location = new Point(230, 358);
            Home_label.Margin = new Padding(5, 0, 5, 0);
            Home_label.Name = "Home_label";
            Home_label.Size = new Size(95, 35);
            Home_label.TabIndex = 0;
            Home_label.TabStop = true;
            Home_label.Text = "Home";
            Home_label.UseWaitCursor = true;
            Home_label.VisitedLinkColor = Color.FromArgb(30, 30, 30);
            Home_label.LinkClicked += Home_label_LinkClicked;
            // 
            // Create_label
            // 
            Create_label.AutoSize = true;
            Create_label.Font = new Font("Georgia", 9F, FontStyle.Italic);
            Create_label.ForeColor = Color.FromArgb(30, 30, 30);
            Create_label.LinkBehavior = LinkBehavior.NeverUnderline;
            Create_label.LinkColor = Color.FromArgb(30, 30, 30);
            Create_label.Location = new Point(1047, 358);
            Create_label.Margin = new Padding(5, 0, 5, 0);
            Create_label.Name = "Create_label";
            Create_label.Size = new Size(103, 35);
            Create_label.TabIndex = 1;
            Create_label.TabStop = true;
            Create_label.Text = "Create";
            Create_label.VisitedLinkColor = Color.FromArgb(30, 30, 30);
            Create_label.LinkClicked += Create_label_LinkClicked;
            // 
            // Updates_label
            // 
            Updates_label.AutoSize = true;
            Updates_label.Font = new Font("Georgia", 9F, FontStyle.Italic);
            Updates_label.ForeColor = Color.FromArgb(30, 30, 30);
            Updates_label.LinkBehavior = LinkBehavior.NeverUnderline;
            Updates_label.LinkColor = Color.FromArgb(30, 30, 30);
            Updates_label.Location = new Point(1988, 358);
            Updates_label.Margin = new Padding(5, 0, 5, 0);
            Updates_label.Name = "Updates_label";
            Updates_label.Size = new Size(126, 35);
            Updates_label.TabIndex = 2;
            Updates_label.TabStop = true;
            Updates_label.Text = "Updates";
            Updates_label.VisitedLinkColor = Color.FromArgb(30, 30, 30);
            Updates_label.LinkClicked += Updates_label_LinkClicked;
            // 
            // Connect_label
            // 
            Connect_label.AutoSize = true;
            Connect_label.Font = new Font("Georgia", 9F, FontStyle.Italic);
            Connect_label.ForeColor = Color.FromArgb(30, 30, 30);
            Connect_label.LinkBehavior = LinkBehavior.NeverUnderline;
            Connect_label.LinkColor = Color.FromArgb(30, 30, 30);
            Connect_label.Location = new Point(2879, 358);
            Connect_label.Margin = new Padding(5, 0, 5, 0);
            Connect_label.Name = "Connect_label";
            Connect_label.Size = new Size(124, 35);
            Connect_label.TabIndex = 3;
            Connect_label.TabStop = true;
            Connect_label.Text = "Connect";
            Connect_label.VisitedLinkColor = Color.FromArgb(30, 30, 30);
            Connect_label.LinkClicked += Connect_label_LinkClicked;
            // 
            // user_textbox
            // 
            user_textbox.Location = new Point(149, 69);
            user_textbox.Margin = new Padding(5);
            user_textbox.MaxLength = 30;
            user_textbox.Name = "user_textbox";
            user_textbox.Size = new Size(408, 61);
            user_textbox.TabIndex = 4;
            // 
            // password_textbox
            // 
            password_textbox.HideSelection = false;
            password_textbox.Location = new Point(149, 157);
            password_textbox.Margin = new Padding(5);
            password_textbox.MaxLength = 25;
            password_textbox.Name = "password_textbox";
            password_textbox.Size = new Size(408, 61);
            password_textbox.TabIndex = 5;
            password_textbox.UseSystemPasswordChar = true;
            // 
            // Login
            // 
            Login.AutoSize = true;
            Login.Font = new Font("Georgia", 9F);
            Login.ForeColor = Color.FromArgb(30, 30, 30);
            Login.Location = new Point(301, 18);
            Login.Margin = new Padding(5, 0, 5, 0);
            Login.Name = "Login";
            Login.Size = new Size(91, 35);
            Login.TabIndex = 6;
            Login.Text = "Login";
            // 
            // Username
            // 
            Username.AutoSize = true;
            Username.Font = new Font("Georgia", 9F);
            Username.ForeColor = Color.FromArgb(30, 30, 30);
            Username.Location = new Point(-5, 69);
            Username.Margin = new Padding(5, 0, 5, 0);
            Username.Name = "Username";
            Username.Size = new Size(152, 35);
            Username.TabIndex = 7;
            Username.Text = "Username";
            // 
            // Password
            // 
            Password.AutoSize = true;
            Password.Font = new Font("Georgia", 9F);
            Password.ForeColor = Color.FromArgb(30, 30, 30);
            Password.Location = new Point(0, 157);
            Password.Margin = new Padding(5, 0, 5, 0);
            Password.Name = "Password";
            Password.Size = new Size(141, 35);
            Password.TabIndex = 8;
            Password.Text = "Password";
            // 
            // LoginButton
            // 
            LoginButton.Font = new Font("Georgia", 9F);
            LoginButton.ForeColor = Color.FromArgb(30, 30, 30);
            LoginButton.Location = new Point(14, 227);
            LoginButton.Margin = new Padding(5);
            LoginButton.Name = "LoginButton";
            LoginButton.Size = new Size(310, 77);
            LoginButton.TabIndex = 9;
            LoginButton.Text = "Login";
            LoginButton.UseVisualStyleBackColor = true;
            LoginButton.Click += LoginButton_Click;
            // 
            // Reset_button
            // 
            Reset_button.Font = new Font("Georgia", 9F);
            Reset_button.Location = new Point(409, 227);
            Reset_button.Margin = new Padding(5);
            Reset_button.Name = "Reset_button";
            Reset_button.Size = new Size(412, 77);
            Reset_button.TabIndex = 10;
            Reset_button.Text = "Reset Password";
            Reset_button.UseVisualStyleBackColor = true;
            Reset_button.Click += Reset_button_Click;
            // 
            // welcome_message
            // 
            welcome_message.AutoSize = true;
            welcome_message.Font = new Font("Georgia", 26.1F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            welcome_message.ForeColor = Color.FromArgb(26, 72, 136);
            welcome_message.Location = new Point(2100, 148);
            welcome_message.Margin = new Padding(5, 0, 5, 0);
            welcome_message.Name = "welcome_message";
            welcome_message.Size = new Size(0, 99);
            welcome_message.TabIndex = 11;
            // 
            // error_label
            // 
            error_label.AutoSize = true;
            error_label.Font = new Font("Georgia", 9F);
            error_label.ForeColor = Color.FromArgb(30, 30, 30);
            error_label.Location = new Point(581, 88);
            error_label.Name = "error_label";
            error_label.Size = new Size(0, 35);
            error_label.TabIndex = 12;
            // 
            // login_attempt_count
            // 
            login_attempt_count.AutoSize = true;
            login_attempt_count.Font = new Font("Georgia", 9F);
            login_attempt_count.Location = new Point(581, 164);
            login_attempt_count.Name = "login_attempt_count";
            login_attempt_count.Size = new Size(0, 35);
            login_attempt_count.TabIndex = 13;
            // 
            // welcome_user
            // 
            welcome_user.AutoSize = true;
            welcome_user.Location = new Point(14, 1007);
            welcome_user.Name = "welcome_user";
            welcome_user.Size = new Size(0, 54);
            welcome_user.TabIndex = 14;
            // 
            // Growth
            // 
            AutoScaleDimensions = new SizeF(28F, 54F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(233, 228, 215);
            ClientSize = new Size(3278, 1527);
            Controls.Add(welcome_user);
            Controls.Add(login_attempt_count);
            Controls.Add(error_label);
            Controls.Add(welcome_message);
            Controls.Add(Reset_button);
            Controls.Add(LoginButton);
            Controls.Add(Password);
            Controls.Add(Username);
            Controls.Add(Login);
            Controls.Add(password_textbox);
            Controls.Add(user_textbox);
            Controls.Add(Connect_label);
            Controls.Add(Updates_label);
            Controls.Add(Create_label);
            Controls.Add(Home_label);
            Font = new Font("Georgia", 14F);
            ForeColor = Color.FromArgb(30, 30, 30);
            Margin = new Padding(5);
            Name = "Growth";
            Text = "Window";
            Load += Growth_Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private LinkLabel Home_label;
        private LinkLabel Create_label;
        private LinkLabel Updates_label;
        private LinkLabel Connect_label;
        private TextBox user_textbox;
        private TextBox password_textbox;
        private Label Login;
        private Label Username;
        private Label Password;
        private Button LoginButton;
        private Button Reset_button;
        private Label welcome_message;
        private Label error_label;
        private Label login_attempt_count;
        private Label welcome_user;
    }
}
