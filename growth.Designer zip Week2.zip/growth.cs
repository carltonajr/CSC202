namespace growth_c_sharp
{
    public partial class Growth : Form
    {
        int loginattempts = 0;
        string currentUser = "";
        bool isLoggedIn = false;
        public Growth()
        {
            InitializeComponent();
        }

        private void Home_label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Returns to Home Page");
        }

        private void Create_label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Link to the page where you can create and manage meal plans, if logged in. If not logged in, it will bring up the login action.");
        }
        private void Updates_label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Link to the company updates and information page.");
        }
        private void Connect_label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Link to the connection pages such as the company website and social media pages.");
        }
        private void LoginButton_Click(object sender, EventArgs e)
        {
            if (user_textbox.TextLength < 5 || password_textbox.TextLength < 8)
            {
                loginattempts += 1;
                if (loginattempts < 5)
                {
                    login_attempt_count.Text = "Login attempts remaining: " + (5 - loginattempts);
                    error_label.Text = "Please check username or password.";
                }                    
            }
            else
            {
                isLoggedIn = true;
            }

            if (isLoggedIn == true)
            {
                LoginButton.Enabled = false;
                Reset_button.Enabled = false;
                login_attempt_count.Text = "";
                welcome_user.Text = "welcome, " + user_textbox.Text;
                error_label.Text = "";
                LoginButton.Visible = false;
                Reset_button.Visible = false;
                user_textbox.Visible = false;
                password_textbox.Visible = false;
                Username.Visible = false;
                Password.Visible = false;
            }
        }

        private void Reset_button_Click(object sender, EventArgs e)
        {
            welcome_message.Text = "";
            LoginButton.Enabled = false;
            Create_label.Enabled = false;
            Updates_label.Enabled = false;
            Connect_label.Enabled = false;

            LoginButton.Visible= false;
            Create_label.Visible = false;
            Updates_label.Visible = false;
            Connect_label.Visible = false;

        }
        private void Growth_Form1_Load(object sender, EventArgs e)
        {
            welcome_message.Text = "growth.";
        }
        
    }
}
