﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Text;
using System.Windows.Forms;

namespace growth_c_sharp
{
    // Meal plan form class that manages food tracking functionality
    public partial class meal_plan : Form
    {
        // Constructor that runs when the meal plan form is created
        // Initializes all UI components on the form
        public meal_plan()
        {
            InitializeComponent();
        }

        // Function that adds a food item to the ListView tracker
        // Returns true if the item is added successfully, otherwise false
        public bool AddFoodToTracker(string inventory_id, string foodName, string food_type, int est_calories, int est_sugar)
        {
            try
            {
                // Creates a new ListViewItem using the food name
                ListViewItem newfood = new ListViewItem(foodName);

                // Adds the new food item to the ListView control
                foodList.Items.Add(newfood);

                // Returns true to indicate the food was added successfully
                return true;
            }
            catch
            {
                // Returns false if an error occurs while adding the item
                return false;
            }
        }

        // Event handler for when the "Add Foods" button is clicked
        private void add_foods_Click(object sender, EventArgs e)
        {
            // Future implementation:
            // inventory_id -> unique ID for the food
            // foodName -> name of the food
            // food_type -> category of food
            // est_calories -> estimated calorie count
            // est_sugar -> estimated sugar content

            // Displays a temporary message to the user
            MessageBox.Show(
                "This will show a menu that allows you to add different foods to the inventory.",
                "In Progress", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
