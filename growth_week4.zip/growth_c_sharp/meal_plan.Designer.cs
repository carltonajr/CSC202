﻿namespace growth_c_sharp
{
    partial class meal_plan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            foodList = new ListView();
            id = new ColumnHeader();
            food_name = new ColumnHeader();
            food_type = new ColumnHeader();
            avg_calories = new ColumnHeader();
            avg_sugar = new ColumnHeader();
            add_foods = new Button();
            edit_inventory = new Button();
            foodname = new TextBox();
            textBox2 = new TextBox();
            foodtype = new ComboBox();
            SuspendLayout();
            // 
            // foodList
            // 
            foodList.BackColor = Color.FromArgb(70, 44, 87);
            foodList.BorderStyle = BorderStyle.None;
            foodList.Columns.AddRange(new ColumnHeader[] { id, food_name, food_type, avg_calories, avg_sugar });
            foodList.ForeColor = Color.FromArgb(233, 228, 215);
            foodList.Location = new Point(459, 306);
            foodList.Name = "foodList";
            foodList.Size = new Size(1872, 592);
            foodList.TabIndex = 17;
            foodList.UseCompatibleStateImageBehavior = false;
            // 
            // id
            // 
            id.DisplayIndex = 4;
            id.Text = "id";
            // 
            // food_name
            // 
            food_name.DisplayIndex = 0;
            food_name.Text = "Food Name";
            // 
            // food_type
            // 
            food_type.DisplayIndex = 3;
            food_type.Text = "food_type";
            // 
            // avg_calories
            // 
            avg_calories.DisplayIndex = 1;
            avg_calories.Text = "AVG Calories";
            // 
            // avg_sugar
            // 
            avg_sugar.DisplayIndex = 2;
            avg_sugar.Text = "AVG Sugar";
            // 
            // add_foods
            // 
            add_foods.Font = new Font("Georgia", 10F);
            add_foods.Location = new Point(227, 306);
            add_foods.Name = "add_foods";
            add_foods.Size = new Size(188, 58);
            add_foods.TabIndex = 20;
            add_foods.Text = "Add Foods";
            add_foods.UseVisualStyleBackColor = true;
            add_foods.Click += add_foods_Click;
            // 
            // edit_inventory
            // 
            edit_inventory.Font = new Font("Georgia", 10F);
            edit_inventory.Location = new Point(227, 415);
            edit_inventory.Name = "edit_inventory";
            edit_inventory.Size = new Size(188, 103);
            edit_inventory.TabIndex = 19;
            edit_inventory.Text = "Edit Inventory";
            edit_inventory.UseVisualStyleBackColor = true;
            // 
            // foodname
            // 
            foodname.Font = new Font("Georgia", 14F);
            foodname.Location = new Point(514, 235);
            foodname.MaxLength = 20;
            foodname.Name = "foodname";
            foodname.Size = new Size(250, 61);
            foodname.TabIndex = 21;
            foodname.Visible = false;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Georgia", 14F);
            textBox2.Location = new Point(1373, 235);
            textBox2.MaxLength = 20;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(250, 61);
            textBox2.TabIndex = 22;
            textBox2.TabStop = false;
            textBox2.Visible = false;
            // 
            // foodtype
            // 
            foodtype.Font = new Font("Georgia", 14F);
            foodtype.FormattingEnabled = true;
            foodtype.Items.AddRange(new object[] { "Fruit", "Vegetables", "Protein", "Grains", "Herb", "Other" });
            foodtype.Location = new Point(856, 234);
            foodtype.Name = "foodtype";
            foodtype.Size = new Size(409, 62);
            foodtype.TabIndex = 23;
            foodtype.Text = "Select Food Type";
            foodtype.Visible = false;
            // 
            // meal_plan
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(233, 228, 215);
            ClientSize = new Size(2744, 940);
            Controls.Add(foodtype);
            Controls.Add(textBox2);
            Controls.Add(foodname);
            Controls.Add(add_foods);
            Controls.Add(edit_inventory);
            Controls.Add(foodList);
            Name = "meal_plan";
            Text = "Meal Plan Window";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        public ListView foodList;
        private ColumnHeader id;
        private ColumnHeader food_name;
        private ColumnHeader food_type;
        private ColumnHeader avg_calories;
        private ColumnHeader avg_sugar;
        private Button add_foods;
        private Button edit_inventory;
        private TextBox foodname;
        private TextBox textBox2;
        private ComboBox foodtype;
    }
}