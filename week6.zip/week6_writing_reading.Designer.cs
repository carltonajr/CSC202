﻿namespace nba_Pickem
{
    partial class week6_writing_reading
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            load_label = new Label();
            Demo1_load_button = new Button();
            text_on_load_click = new Label();
            label1 = new Label();
            Demo2_load_button = new Button();
            File_title_describe = new Label();
            Click_to_write = new Button();
            write_to_file = new TextBox();
            save_text = new Button();
            submit_file_name = new Button();
            enter_file_name = new TextBox();
            name_new_file = new Label();
            write_file_text_label = new Label();
            SuspendLayout();
            // 
            // load_label
            // 
            load_label.AutoSize = true;
            load_label.Location = new Point(559, 231);
            load_label.Margin = new Padding(5, 0, 5, 0);
            load_label.Name = "load_label";
            load_label.Size = new Size(267, 54);
            load_label.TabIndex = 0;
            load_label.Text = "Demo File 1";
            // 
            // Demo1_load_button
            // 
            Demo1_load_button.Location = new Point(539, 322);
            Demo1_load_button.Margin = new Padding(5);
            Demo1_load_button.Name = "Demo1_load_button";
            Demo1_load_button.Size = new Size(310, 77);
            Demo1_load_button.TabIndex = 2;
            Demo1_load_button.Text = "Load Demo 1";
            Demo1_load_button.UseVisualStyleBackColor = true;
            Demo1_load_button.Click += Demo1_load_button_Click;
            // 
            // text_on_load_click
            // 
            text_on_load_click.AutoSize = true;
            text_on_load_click.Location = new Point(539, 607);
            text_on_load_click.Name = "text_on_load_click";
            text_on_load_click.Size = new Size(0, 54);
            text_on_load_click.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(1089, 231);
            label1.Name = "label1";
            label1.Size = new Size(273, 54);
            label1.TabIndex = 4;
            label1.Text = "Demo File 2";
            // 
            // Demo2_load_button
            // 
            Demo2_load_button.Location = new Point(1068, 322);
            Demo2_load_button.Name = "Demo2_load_button";
            Demo2_load_button.Size = new Size(310, 77);
            Demo2_load_button.TabIndex = 5;
            Demo2_load_button.Text = "Load Demo 2";
            Demo2_load_button.UseVisualStyleBackColor = true;
            Demo2_load_button.Click += Demo2_load_button_Click;
            // 
            // File_title_describe
            // 
            File_title_describe.AutoSize = true;
            File_title_describe.Location = new Point(539, 445);
            File_title_describe.Name = "File_title_describe";
            File_title_describe.Size = new Size(0, 54);
            File_title_describe.TabIndex = 6;
            // 
            // Click_to_write
            // 
            Click_to_write.Location = new Point(1604, 322);
            Click_to_write.Name = "Click_to_write";
            Click_to_write.Size = new Size(320, 77);
            Click_to_write.TabIndex = 7;
            Click_to_write.Text = "Click to Write";
            Click_to_write.UseVisualStyleBackColor = true;
            Click_to_write.Click += Click_to_write_Click;
            // 
            // write_to_file
            // 
            write_to_file.Location = new Point(539, 149);
            write_to_file.Multiline = true;
            write_to_file.Name = "write_to_file";
            write_to_file.Size = new Size(1039, 675);
            write_to_file.TabIndex = 8;
            write_to_file.Visible = false;
            // 
            // save_text
            // 
            save_text.Location = new Point(1657, 467);
            save_text.Name = "save_text";
            save_text.Size = new Size(188, 58);
            save_text.TabIndex = 9;
            save_text.Text = "Submit";
            save_text.UseVisualStyleBackColor = true;
            save_text.Visible = false;
            save_text.Click += save_text_Click;
            // 
            // submit_file_name
            // 
            submit_file_name.Location = new Point(983, 534);
            submit_file_name.Name = "submit_file_name";
            submit_file_name.Size = new Size(188, 58);
            submit_file_name.TabIndex = 10;
            submit_file_name.Text = "Save";
            submit_file_name.UseVisualStyleBackColor = true;
            submit_file_name.Visible = false;
            submit_file_name.Click += submit_file_name_Click;
            // 
            // enter_file_name
            // 
            enter_file_name.Location = new Point(954, 467);
            enter_file_name.Name = "enter_file_name";
            enter_file_name.Size = new Size(250, 61);
            enter_file_name.TabIndex = 11;
            enter_file_name.Visible = false;
            // 
            // name_new_file
            // 
            name_new_file.AutoSize = true;
            name_new_file.Location = new Point(921, 322);
            name_new_file.Name = "name_new_file";
            name_new_file.Size = new Size(314, 54);
            name_new_file.TabIndex = 12;
            name_new_file.Text = "Name the File";
            name_new_file.Visible = false;
            // 
            // write_file_text_label
            // 
            write_file_text_label.AutoSize = true;
            write_file_text_label.Location = new Point(851, 67);
            write_file_text_label.Name = "write_file_text_label";
            write_file_text_label.Size = new Size(426, 54);
            write_file_text_label.TabIndex = 13;
            write_file_text_label.Text = "Enter File Contents";
            write_file_text_label.Visible = false;
            // 
            // week6_writing_reading
            // 
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(3315, 1310);
            Controls.Add(write_file_text_label);
            Controls.Add(name_new_file);
            Controls.Add(enter_file_name);
            Controls.Add(submit_file_name);
            Controls.Add(save_text);
            Controls.Add(write_to_file);
            Controls.Add(Click_to_write);
            Controls.Add(File_title_describe);
            Controls.Add(Demo2_load_button);
            Controls.Add(label1);
            Controls.Add(text_on_load_click);
            Controls.Add(Demo1_load_button);
            Controls.Add(load_label);
            Font = new Font("Georgia", 14F);
            Margin = new Padding(5);
            Name = "week6_writing_reading";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label load_label;
        private Button Demo1_load_button;
        private Label text_on_load_click;
        private Label label1;
        private Button Demo2_load_button;
        private Label File_title_describe;
        private Button Click_to_write;
        private TextBox write_to_file;
        private Button save_text;
        private Button submit_file_name;
        private TextBox enter_file_name;
        private Label name_new_file;
        private Label write_file_text_label;
    }
}
