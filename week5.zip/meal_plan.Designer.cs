﻿namespace growth_c_sharp
{
    partial class meal_plan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            foodList = new ListView();
            food_name = new ColumnHeader();
            food_type = new ColumnHeader();
            avg_calories = new ColumnHeader();
            avg_sugar = new ColumnHeader();
            add_foods = new Button();
            edit_inventory = new Button();
            foodname = new TextBox();
            calories_est_textbox = new TextBox();
            foodtype = new ComboBox();
            sugar_est_textbox = new TextBox();
            foodname_label = new Label();
            foodtype_label = new Label();
            calories_label = new Label();
            sugar_label = new Label();
            submit_entry_button = new Button();
            entries_amount_textbox = new TextBox();
            entries_amount_label = new Label();
            submit_num_entries = new Button();
            SuspendLayout();
            // 
            // foodList
            // 
            foodList.AutoArrange = false;
            foodList.BackColor = Color.FromArgb(70, 44, 87);
            foodList.BorderStyle = BorderStyle.None;
            foodList.Columns.AddRange(new ColumnHeader[] { food_name, food_type, avg_calories, avg_sugar });
            foodList.ForeColor = Color.FromArgb(233, 228, 215);
            foodList.Location = new Point(756, 403);
            foodList.Margin = new Padding(5, 4, 5, 4);
            foodList.Name = "foodList";
            foodList.Size = new Size(2000, 780);
            foodList.TabIndex = 17;
            foodList.UseCompatibleStateImageBehavior = false;
            // 
            // food_name
            // 
            food_name.Text = "Food Name";
            food_name.Width = 150;
            // 
            // food_type
            // 
            food_type.DisplayIndex = 3;
            food_type.Text = "food_type";
            // 
            // avg_calories
            // 
            avg_calories.DisplayIndex = 1;
            avg_calories.Text = "AVG Calories";
            // 
            // avg_sugar
            // 
            avg_sugar.DisplayIndex = 2;
            avg_sugar.Text = "AVG Sugar";
            // 
            // add_foods
            // 
            add_foods.Font = new Font("Georgia", 10F);
            add_foods.Location = new Point(374, 403);
            add_foods.Margin = new Padding(5, 4, 5, 4);
            add_foods.Name = "add_foods";
            add_foods.Size = new Size(310, 76);
            add_foods.TabIndex = 20;
            add_foods.Text = "Add Foods";
            add_foods.UseVisualStyleBackColor = true;
            add_foods.Click += add_foods_Click;
            // 
            // edit_inventory
            // 
            edit_inventory.Font = new Font("Georgia", 10F);
            edit_inventory.Location = new Point(374, 547);
            edit_inventory.Margin = new Padding(5, 4, 5, 4);
            edit_inventory.Name = "edit_inventory";
            edit_inventory.Size = new Size(310, 136);
            edit_inventory.TabIndex = 19;
            edit_inventory.Text = "Edit Inventory";
            edit_inventory.UseVisualStyleBackColor = true;
            // 
            // foodname
            // 
            foodname.Font = new Font("Georgia", 14F);
            foodname.Location = new Point(374, 297);
            foodname.Margin = new Padding(5, 4, 5, 4);
            foodname.MaxLength = 20;
            foodname.Name = "foodname";
            foodname.Size = new Size(409, 61);
            foodname.TabIndex = 21;
            foodname.Visible = false;
            // 
            // calories_est_textbox
            // 
            calories_est_textbox.Font = new Font("Georgia", 14F);
            calories_est_textbox.Location = new Point(1472, 297);
            calories_est_textbox.Margin = new Padding(5, 4, 5, 4);
            calories_est_textbox.MaxLength = 20;
            calories_est_textbox.Name = "calories_est_textbox";
            calories_est_textbox.Size = new Size(409, 61);
            calories_est_textbox.TabIndex = 22;
            calories_est_textbox.TabStop = false;
            calories_est_textbox.Visible = false;
            // 
            // foodtype
            // 
            foodtype.Font = new Font("Georgia", 14F);
            foodtype.FormattingEnabled = true;
            foodtype.Items.AddRange(new object[] { "Select Food Type", "Fruit", "Vegetables", "Protein", "Grains", "Herb", "Other" });
            foodtype.Location = new Point(916, 296);
            foodtype.Margin = new Padding(5, 4, 5, 4);
            foodtype.Name = "foodtype";
            foodtype.Size = new Size(402, 62);
            foodtype.TabIndex = 23;
            foodtype.Visible = false;
            // 
            // sugar_est_textbox
            // 
            sugar_est_textbox.Font = new Font("Georgia", 14F);
            sugar_est_textbox.Location = new Point(2039, 296);
            sugar_est_textbox.Margin = new Padding(5, 4, 5, 4);
            sugar_est_textbox.Name = "sugar_est_textbox";
            sugar_est_textbox.Size = new Size(409, 61);
            sugar_est_textbox.TabIndex = 24;
            sugar_est_textbox.Visible = false;
            // 
            // foodname_label
            // 
            foodname_label.AutoSize = true;
            foodname_label.Location = new Point(481, 221);
            foodname_label.Name = "foodname_label";
            foodname_label.Size = new Size(139, 54);
            foodname_label.TabIndex = 25;
            foodname_label.Text = "name";
            foodname_label.Visible = false;
            // 
            // foodtype_label
            // 
            foodtype_label.AutoSize = true;
            foodtype_label.Location = new Point(1074, 221);
            foodtype_label.Name = "foodtype_label";
            foodtype_label.Size = new Size(112, 54);
            foodtype_label.TabIndex = 26;
            foodtype_label.Text = "type";
            foodtype_label.Visible = false;
            // 
            // calories_label
            // 
            calories_label.AutoSize = true;
            calories_label.Location = new Point(1484, 221);
            calories_label.Name = "calories_label";
            calories_label.Size = new Size(397, 54);
            calories_label.TabIndex = 27;
            calories_label.Text = "estimated calories";
            calories_label.Visible = false;
            // 
            // sugar_label
            // 
            sugar_label.AutoSize = true;
            sugar_label.Location = new Point(2069, 221);
            sugar_label.Name = "sugar_label";
            sugar_label.Size = new Size(352, 54);
            sugar_label.TabIndex = 28;
            sugar_label.Text = "estimated sugar";
            sugar_label.Visible = false;
            // 
            // submit_entry_button
            // 
            submit_entry_button.Location = new Point(2536, 296);
            submit_entry_button.Name = "submit_entry_button";
            submit_entry_button.Size = new Size(188, 58);
            submit_entry_button.TabIndex = 29;
            submit_entry_button.Text = "submit";
            submit_entry_button.UseVisualStyleBackColor = true;
            submit_entry_button.Visible = false;
            submit_entry_button.Click += submit_entry_button_Click;
            // 
            // entries_amount_textbox
            // 
            entries_amount_textbox.Location = new Point(756, 193);
            entries_amount_textbox.Name = "entries_amount_textbox";
            entries_amount_textbox.Size = new Size(250, 61);
            entries_amount_textbox.TabIndex = 30;
            entries_amount_textbox.Visible = false;
            // 
            // entries_amount_label
            // 
            entries_amount_label.AutoSize = true;
            entries_amount_label.Location = new Point(481, 118);
            entries_amount_label.Name = "entries_amount_label";
            entries_amount_label.Size = new Size(782, 54);
            entries_amount_label.TabIndex = 31;
            entries_amount_label.Text = "How Many Entries Are You Making?";
            entries_amount_label.Visible = false;
            // 
            // submit_num_entries
            // 
            submit_num_entries.Location = new Point(1039, 193);
            submit_num_entries.Name = "submit_num_entries";
            submit_num_entries.Size = new Size(188, 58);
            submit_num_entries.TabIndex = 32;
            submit_num_entries.Text = "submit";
            submit_num_entries.UseVisualStyleBackColor = true;
            submit_num_entries.Visible = false;
            submit_num_entries.Click += submit_num_entries_Click;
            // 
            // meal_plan
            // 
            AutoScaleMode = AutoScaleMode.None;
            AutoScroll = true;
            BackColor = Color.FromArgb(233, 228, 215);
            ClientSize = new Size(2269, 1082);
            Controls.Add(submit_num_entries);
            Controls.Add(entries_amount_label);
            Controls.Add(entries_amount_textbox);
            Controls.Add(submit_entry_button);
            Controls.Add(sugar_label);
            Controls.Add(calories_label);
            Controls.Add(foodtype_label);
            Controls.Add(foodname_label);
            Controls.Add(sugar_est_textbox);
            Controls.Add(foodtype);
            Controls.Add(calories_est_textbox);
            Controls.Add(foodname);
            Controls.Add(add_foods);
            Controls.Add(edit_inventory);
            Controls.Add(foodList);
            Font = new Font("Georgia", 14F);
            Name = "meal_plan";
            StartPosition = FormStartPosition.WindowsDefaultBounds;
            Text = "Meal Plan Window";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        public ListView foodList;
        private ColumnHeader food_name;
        private ColumnHeader food_type;
        private ColumnHeader avg_calories;
        private ColumnHeader avg_sugar;
        private Button add_foods;
        private Button edit_inventory;
        private TextBox foodname;
        private TextBox calories_est_textbox;
        private ComboBox foodtype;
        private TextBox sugar_est_textbox;
        private Label foodname_label;
        private Label foodtype_label;
        private Label calories_label;
        private Label sugar_label;
        private Button submit_entry_button;
        private TextBox entries_amount_textbox;
        private Label entries_amount_label;
        private Button submit_num_entries;
    }
}