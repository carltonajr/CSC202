﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace growth_c_sharp
{
    // Meal plan form class that manages food tracking functionality
    public partial class meal_plan : Form
    {
        // Constructor that runs when the meal plan form is created
        // Initializes all UI components on the form
        public meal_plan()
        {
            InitializeComponent();
        }

        // Function that adds a food item to the ListView tracker
        // Returns true if the item is added successfully, otherwise false
        public bool AddFoodToTracker(string foodName, string food_type, double est_calories, double est_sugar)
        {
            try
            {
                // Creates a new ListViewItem using the food name
                ListViewItem new_food = new ListViewItem(foodName);
                ListViewItem new_food_type = new ListViewItem(food_type);

                foodList.Items.Add(new_food);
                foodList.Items.Add(new_food_type);

                // Returns true to indicate the food was added successfully
                return true;
            }
            catch
            {
                // Returns false if an error occurs while adding the item
                return false;
            }
        }
        //Converts the input text to the needed data type
        public double Data_Type_Convert(string value)
        {
            // try parsing the value and converting to double
            try
            {
                double ready_to_store = double.Parse(value);
                return ready_to_store;
            }
            // loads a message box when the value is unable to be changed to a double data type.
            catch
            {
                // sets the return value of 0
                return 0.0;
            }
        }

        // Event handler for when the "Add Foods" button is clicked
        // Brings up user input for number of entries wanted.
        private void add_foods_Click(object sender, EventArgs e)
        {
            entries_amount_label.Visible = true;
            entries_amount_textbox.Visible = true;
            submit_num_entries.Visible = true;
        }
        // When clicking the submit entry button perform these checks
        // if they pass all conditions, add the entries to the listview
        // and 'reset' the form
        private void submit_entry_button_Click(object sender, EventArgs e)
        {
            
            edit_inventory.Enabled = false;
            if (foodname.TextLength < 3)
            {
                MessageBox.Show("Please review the name of the food given.", "Missing/ Incomplete Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (foodtype.SelectedIndex <= 0)
            {
                MessageBox.Show("Please select a food type.", "Missing/ Incomplete Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (Data_Type_Convert(calories_est_textbox.Text) == 0.0 || Data_Type_Convert(sugar_est_textbox.Text) == 0.0)
            {
                MessageBox.Show("Please check calories or sugar amount inputs", "Data Entry Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            // string foodName, string food_type, double est_calories, double est_sugar
            {
                if (Validate_num(entries_amount_textbox.Text) <= 10)
                {
                    AddFoodToTracker(foodname.Text, foodtype.SelectedText, Data_Type_Convert(calories_est_textbox.Text), Data_Type_Convert(sugar_est_textbox.Text));
                    foodname.Text = "";
                    foodtype.SelectedIndex = 0;
                    calories_est_textbox.Text = "";
                    sugar_est_textbox.Text = "";
                    edit_inventory.Enabled = true;
                    add_foods.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Maximum of 10 Entries per Batch at this time.", "Batch Entry Reached", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }
        // Completes same task as Data_Type_Convert but with an int rather than double
        public int Validate_num(string entries)
        {
            try
            {
                int ready_to_store_int = int.Parse(entries);
                return ready_to_store_int;
            }
            // loads a message box when the value is unable to be changed to an int data type.
            catch
            {
                // sets the return value of 0
                return 0;
            }

        }
        // Validate_num runs making sure input is converted to int successfully.
        // Event handler for Enabling, disabling and making elements visible.
        private void submit_num_entries_Click(object sender, EventArgs e)
        {
            Validate_num(entries_amount_textbox.Text);

            if (Validate_num(entries_amount_textbox.Text) == 0)
            {
                MessageBox.Show("Please check your input, whole numbers only.", "Data Entry Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error
                    );
            }
            else
            {
                // Hide "Entries Form" elements after successfully input.
                entries_amount_label.Visible = false;
                entries_amount_textbox.Visible = false;
                submit_num_entries.Visible = false;
                // Array of food names (string)
                string[] stored_foodNames = new string[Validate_num(entries_amount_textbox.Text)];
                string[] stored_foodTypes = new string[Validate_num(entries_amount_textbox.Text)];

                // Array of calories (int)
                double[] foodCalories = new double[Validate_num(entries_amount_textbox.Text)];
                double[] foodSugar = new double[Validate_num(entries_amount_textbox.Text)];
                // Enabling, disabling and making elements visible.
                foodname.Visible = true;
                foodname_label.Visible = true;
                foodtype.Visible = true;
                foodtype_label.Visible = true;
                calories_est_textbox.Visible = true;
                calories_label.Visible = true;
                sugar_est_textbox.Visible = true;
                sugar_label.Visible = true;
                submit_entry_button.Visible = true;
                submit_entry_button.Enabled = true;

            }
        }
    }
}
